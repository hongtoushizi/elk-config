import uiRegistry from 'ui/registry/_registry';
export default uiRegistry({
  name: 'devTools',
  index: ['name'],
  order: ['order']
});
