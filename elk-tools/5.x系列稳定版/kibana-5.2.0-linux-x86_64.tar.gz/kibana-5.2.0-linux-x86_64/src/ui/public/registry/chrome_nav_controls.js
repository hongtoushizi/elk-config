import uiRegistry from 'ui/registry/_registry';
export default uiRegistry({
  name: 'chromeNavControls',
  order: ['order']
});
